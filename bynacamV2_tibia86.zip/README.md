# bynacam reloaded v2 - for Tibia 8.6
BynaCam Reloaded v2 is free, open source software to capture and play Tibia videos by network data packets in CAM file format. Software is based on original BynaCam source code. Designed exclusively for Tibia 8.6

Features:
  * BynaCam draws its own GUI using Tibia's internal functions (no external gui).
  * CAM file format works for all modern CAM file players (eg. TibiaCam TV)
  * Censor: Ability to hide certain type of actions by blocking packets (messages, eq, skills, viplist etc)
  * It's written in C++ / Compiled using Dev-C++ 4.9.9.2 from Bloodshed
  * Helps to understand Tibia internals and CAM file structure :)
  
  And many more... ! :)

exoticprgmr 2020
beziak 2010-2012

./Public domain
